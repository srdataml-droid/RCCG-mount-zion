# Mount Zion — Codex Prompt Log

Running log of prompts for Codex, in the order they were worked out.
Mark status as they're run. Update this file little by little as new
prompts come up — don't rewrite history, just append.

---

## 1. API refactor — split /api/counsel
**Status:** ❌ RETIRED — no chatbot at all, this doesn't apply
Confirmed: no PastorBot, no AI chat, no /api/chat route of any kind.
The whole premise of this prompt (splitting a chat route from a save 
route) is void. Meeting requests are just a plain form → 
POST /api/meeting-requests, nothing to split. Kept below for history 
only — do not run this.

<details>
<summary>Original prompt (retired, not to be run)</summary>

```
Refactor /api/counsel into two separate routes, per the updated 
mount-zion-product-spec.md (API Specification section):

1. POST /api/chat — handles the PastorBot conversation only 
   (Ollama Cloud calls). Returns the assistant's response, nothing else.

2. POST /api/meeting-requests — saves a completed scheduling request 
   only (fullName, contact, preferredDateTime, reason) to the 
   meeting_requests table. Keep these exact field names — they're 
   already correct and consistent with connect_cards' fullName pattern.

The frontend (PastorBot.tsx) will need to change to call these two 
routes instead of the single /api/counsel endpoint — likely: chat 
messages go to /api/chat throughout the conversation, then once all 
required fields are collected, a final call to /api/meeting-requests 
saves the record.

Also update GET /api/parishes and GET /api/events, /api/testimonies 
to the cleaner path-based style from the spec (/api/parishes/:slug, 
etc.) if this is a natural fit — otherwise leave those as query-param 
style if the path-based change would be disproportionate effort for 
this route. Your call, but tell me which you chose and why.
```

</details>

---

## 2. New Zealand cleanup — remove remaining Nigeria content
**Status:** ⬜ Not confirmed run

```
Full New Zealand cleanup pass — remove remaining Nigeria-specific content 
and duplicate/fake data across the codebase:

1. DUPLICATE DATA BUG (fix first): App.tsx has its own hardcoded 
   DEPARTMENTS array (around line 63) that duplicates and overrides 
   src/data/parishData.ts's departments. These need to be consolidated 
   into ONE source of truth — use parishData.ts's version, delete the 
   duplicate from App.tsx, and import from parishData.ts instead.

2. REMOVE LEADER/MINISTER NAMES ENTIRELY from departments — not just 
   placeholder them, remove the field from display. Department name + 
   description is sufficient; no leaderName needed. Update the 
   Department type in types.ts, the data, and the rendering in App.tsx 
   (around line 509, "Leader: {dept.leaderName}") to drop this entirely.

3. FIX HARDCODED LAGOS COORDINATES — App.tsx (~line 793) has 
   "LAT/LON: 6.4281° N, 3.4219° E (Lagos Sanctuary)" hardcoded. This is 
   wrong for Mount Zion — replace with Lower Hutt, Wellington's actual 
   coordinates, or remove if not functionally used yet.

4. ConnectCard.tsx (~line 133) — welcome text says "Whether you're 
   visiting Lagos, Rivers, Oyo, or streaming globally online" — replace 
   with wording appropriate to a single NZ parish (no need to reference 
   Nigerian states/regions at all).

5. GivingModal.tsx — entirely Naira/Paystack-branded (₦ symbol throughout, 
   "Paystack Secure Portal," "Nigerian Paystack channels," etc.). Since 
   real Stripe integration is still deferred (Phase 7), just do a 
   cosmetic-only fix for now: swap ₦ for $ (NZD), remove "Paystack" 
   branding/naming throughout, generic "Secure Payment Portal" instead. 
   Do NOT build real Stripe logic yet — this is just removing misleading 
   Nigeria-specific placeholder branding.

6. ParishConfigurator.tsx — multiple "₦0 SaaS" / "₦0 budget" labels and 
   a Naira amount display. Replace ₦ with $ throughout for consistency 
   with the giving modal fix above.
   NOTE: this whole component is being removed anyway per #3 below — 
   skip this step if #3 is done first.

7. App.tsx (~line 420) — comment/UI text "to save Naira data/quota 
   usage" — reword, not currency-specific to this parish.

8. server.ts (~line 186) — comment "Simulating Paystack webhook" — 
   update comment wording, no functional change needed since payments 
   are deferred.

9. metadata.json — project description mentions "Paystack giving 
   integration" — update to generic "giving integration" since the 
   specific processor is still TBD/deferred.

After this pass, do a final grep for "nigeria|naira|lagos|paystack|₦" 
across the whole src/ and confirm zero remaining matches outside of 
this task's own commit history/comments explaining the change.

Append the outcome to mount-zion-project-status.md as usual.
```

---

## 3. Remove the "Novaxis" sidebar
**Status:** ⬜ Not confirmed run

```
Remove the "Novaxis SaaS Panel" — this is leftover demo branding from 
the original AI Studio scaffold, unrelated to the actual site.

1. Remove ParishConfigurator.tsx entirely (or leave the file but stop 
   importing/rendering it — your call on which is cleaner)
2. Remove its import and render call from App.tsx
3. Update the testimony submission message (around line 688) that tells 
   users to open the "Novaxis Panel" to self-approve — this needs 
   different wording since that mechanism is going away. For now, just 
   say testimonies are reviewed before appearing publicly, with no 
   self-approval instructions
4. Update the footer copyright line (around line 838) from "Novaxis 
   Parish-Port Engine © 2026" to something appropriate for Mount Zion — 
   e.g. "RCCG Mount Zion © 2026"

NOTE (updated — admin decision has since reversed twice, see #5): a
real admin page WITH login is planned after all, built after the
church page — not resolved via raw Supabase Studio. In the meantime,
before Phase 8 exists, testimonies will sit pending with no review
mechanism — that's an accepted, temporary gap, not a permanent
solution. Remove the sidebar and update the message/footer regardless;
just don't claim Supabase Studio is "the" solution — it's a stopgap.

Append the outcome to mount-zion-project-status.md as usual.
```

---

## 4. Major simplification pass
**Status:** ⬜ Not confirmed run

```
Major simplification pass, per updated product spec:

1. REMOVE PastorBot entirely — no Ollama, no chat interface, no 
   /api/chat. Delete the Ollama dependency and OLLAMA_API_KEY from 
   .env.example. Replace with a plain form (name, contact, preferred 
   time, reason) that POSTs directly to /api/meeting-requests — no 
   conversation, just a form submit.

2. Departments/Ministries — remove ALL placeholder fields (TO BE 
   FILLED for meetingTime, no leaderName as already done). Just show 
   real name + descriptive text (what the ministry does, who it's for), 
   plus an expandable dropdown/accordion for "how to get involved" info.

3. Drop Small Groups entirely — not being built.

4. Restructure navigation into 5 top-level items, each with a dropdown 
   to sub-pages: Home / About (Departments, Testimonies) / Connect 
   (Connect Card, Prayer Request, Baptism, Meeting Request) / Events 
   (list + calendar view) / Give. Replace the current flat link 
   structure with this.

5. Visual redesign: church-appropriate background imagery, gold + 
   white as the primary palette, black as a minor accent only. Apply 
   site-wide.

6. ~~Also remove any remaining admin-panel/login concepts~~ — 
   **REVERSED, do not do this part.** An admin page with login is 
   wanted after all (see #5 below) — just sequenced after this church 
   page work, not removed. Only items 1-5 above still apply.

Append outcome to mount-zion-project-status.md as usual.
```

---

## 5. Cancel admin panel — use Supabase Studio instead
**Status:** ❌ RETIRED — decision reversed
A real admin page (with login) is wanted after all — sequenced to be
built after the church page is done, not instead of one. Use Supabase
Auth for the login mechanism (not custom-built auth), but the admin
page itself is a real, custom-built page — not raw Supabase Studio.
Kept below for history only — do not run this.

<details>
<summary>Original prompt (retired, not to be run)</summary>

```
Cancel the admin-panel build entirely — no custom admin UI, no login 
system on the church website. 

Confirm the events table (and testimonies, meeting_requests) can be 
edited directly via Supabase's Table Editor with changes reflecting 
immediately on the public site through the existing GET /api/events 
etc. routes — no additional sync or cache layer needed for this to work.

If there's currently any caching on the events/testimonies GET routes 
that would delay a Supabase-made change from showing up publicly, flag 
it — we need near-immediate reflection, not a stale cache.
```

</details>

---

## 6. Move Departments from hardcoded array to a real DB table
**Status:** ⬜ Not confirmed run

```
Add a `departments` table to the Supabase schema (same pattern as 
other tables: id, parishId FK, RLS enabled). Fields: name, description, 
howToJoin (text shown in a dropdown/accordion on the site).

Migrate the current hardcoded DEPARTMENTS array (already being 
consolidated per prompt #2) into this table as seed data — real Mount 
Zion department names/descriptions, no leaderName or meetingTime 
fields at all.

Update App.tsx to fetch departments from the API/Supabase at runtime 
instead of importing a hardcoded array. Add a GET /api/departments 
route following the same pattern as /api/events.

This closes a gap: the goal is that the church's tech dept can update 
department info themselves later (via the admin page or Supabase 
directly) without ever touching code or redeploying. A hardcoded array 
fails that requirement no matter how simple it looks.

Once done, parishData.ts should be treated as a one-time seed script, 
not a live data source — confirm the app is actually reading parish 
info (name, address, service times, etc.) from Supabase at runtime too, 
not from this file, and flag if that's not already the case.

Append outcome to mount-zion-project-status.md as usual.
```

---

*(Add new prompts below this line as they come up.)*
