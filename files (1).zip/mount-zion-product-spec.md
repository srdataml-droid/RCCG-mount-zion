# Mount Zion Website — Product Specification

---

## 1. Product Vision

A single, honest, low-maintenance website for RCCG Mount Zion (Lower
Hutt, Wellington, NZ) that helps first-time visitors find the church,
keeps the congregation connected between services, and gives Assistant
Pastor Hannah Adeniran a simple way to receive meeting requests —
built and run entirely on free-tier infrastructure, with an underlying
architecture that could later support additional RCCG parishes without
a rebuild, should that path be chosen.

**Scope (updated)**
- **No login for the public church page** — everyone browsing the
  site, submitting forms, etc. — no accounts, no auth
- **Login required for the admin page only** — a separate, real admin
  section (add/edit events, review testimonies and meeting requests),
  authenticated via Supabase Auth rather than custom-built auth
- **Sequencing**: church page first, admin page second — not built
  in parallel
- No multi-parish activation — single parish only, permanently, not
  just for now
- No AI assistant of any kind — PastorBot has been removed entirely
- Not a real-time payment/giving platform yet (deferred)

---

## 2. Feature Matrix

| Feature | Priority | Status |
|---|---|---|
| Parish identity (name, address, service times) | MVP | ✅ Done |
| Departments/ministries (text + how-to-join dropdown, no placeholders) | MVP | 🟡 Needs simplification pass — remove TODO placeholders |
| Events listing | MVP | 🟡 Schema ready, no real events yet |
| Testimonies (submit + display, moderated) | MVP | 🟡 Schema ready, empty |
| Connect Card (first-timer form) | MVP | ✅ Built (from original scaffold) |
| Simple meeting/contact form (no AI) | MVP | ⬜ Replaces PastorBot — not yet built |
| Watch Live (Facebook link-out) | MVP | 🟡 Decided, not yet implemented |
| Giving/donations (Stripe) | Deferred | ⬜ Not started |
| Facebook feed embed | Nice-to-have | ⬜ Not started |
| Share buttons | Nice-to-have | ⬜ Not started |
| Service reminder emails | Nice-to-have | ⬜ Not started |
| Ministry pages (Adult / Youth / Kids) | Documented | ⬜ Not started — currently flat Departments list only |
| Expanded Connect Card (address, spouse, children, visit count, etc.) | Documented | ⬜ Not started — current form has fewer fields |
| Prayer Request (separate from Connect Card) | Documented | ⬜ Not started |
| Baptism signup form | Documented | ⬜ Not started |
| Daily devotion / spiritual rhythms content | Documented | ⬜ Not started — static content, no forms |
| Events calendar view (folded into main nav, not standalone) | Documented | ⬜ Not started — current events are list-only |
| Homepage hero image slider | Documented | ⬜ Not started — current hero is static |
| Church-themed visual redesign (gold/white, black accent) | MVP | ⬜ Not started |
| Simplified 4-5 page navigation with dropdowns | MVP | ⬜ Not started |
| Church page (public, no login) | MVP — build first | 🟡 In progress — current priority |
| Admin page (login required, via Supabase Auth) | MVP — build after church page | ⬜ Not started — deliberately sequenced later |
| Counseling services (separate from meeting form) | **Decision pending** | ⬜ Not started — whether this is real/staffed vs. aspirational is undecided; do not build until resolved |

---

## 3. User Journeys

**First-time visitor** (primary journey)
Lands on homepage → sees service times + address → clicks "I'm New
Here" (planned) → fills Connect Card or just shows up → optionally
browses Departments to find where to get involved.

**Returning member checking service info**
Lands on homepage → checks this week's service time/location → clicks
"Watch us on Facebook" if attending remotely.

**Someone needing pastoral contact**
Navigates to meeting request page → fills a plain form (name, contact,
preferred time, reason) → request saved for Pastor Hannah's manual
review → (future) receives confirmation once reviewed. No chatbot, no
conversation — a straightforward form submission.

**Congregant sharing a testimony**
Submits testimony via form → enters moderation queue (`isApproved =
false`) → appears publicly once approved → (future) can be shared
out via Share buttons.

**Pastor/Admin** (Phase 8, built after the public church page)
Logs into the admin page (Supabase Auth) → reviews pending meeting
requests and testimonies, approves/actions them → adds/edits/deletes
events directly rather than via code edits.

---

## 4. Information Architecture

**Restructured per simplification direction**: fewer top-level pages,
each with a dropdown to related sub-pages, rather than a flat list of
many separate top-level links.

```
Home            (hero, service times, quick links)
About           ▾ Departments/Ministries · Testimonies
Connect         ▾ Connect Card · Prayer Request · Baptism · Meeting Request
Events          ▾ Upcoming Events · Calendar View
Give            (deferred — placeholder for now)
[Facebook link-out]     Watch Live (external, not a page)

/admin (Phase 8, built later)   Login (Supabase Auth) → 
                                 add/edit events, review testimonies 
                                 and meeting requests
```

Five main nav items on the public church page, each expanding to its
related pages — matches the "simple to navigate" direction. The admin
page is a separate section entirely, requiring login, and is not part
of the public nav at all — it's built and accessed independently, after
the church page is done.

**Visual theme (new direction)**: church-appropriate background
imagery, gold and white as the primary palette, black used sparingly
as an accent — replacing whatever the current placeholder styling is.
Applies site-wide, not just to specific components.

---

## 5. Wireframes

Described at a structural level (full visual wireframes available on
request via the diagram/mockup tool):

**Home**: Hero banner (mountain/Obadiah 1:17 imagery) → Service times
strip → "I'm New Here" + "Watch Live" CTAs → Departments preview →
Testimonies preview → Footer (address, contact, social links).

**Meeting request form**: Plain form — name, contact, preferred time,
reason fields → submit button → confirmation message once submitted.
No chat interface, no conversation, no AI involved.

**Departments**: Grid/list of cards — name, short description only (no
leader name, no meeting time placeholder), each with an expandable
dropdown/accordion for "how to get involved" details.

**Admin page** (Phase 8, not designed yet): Login screen (Supabase
Auth) → dashboard with an events list (add/edit/delete), a testimonies
queue (approve/reject), and a meeting requests list. Deferred until the
church page is finished — not worth designing in detail yet.

*(Say the word and I can generate actual visual wireframes for any of
these using the diagram tool, rather than just descriptions.)*

---

## 6. Database Schema (Supabase / Postgres)

| Table | Purpose | Key fields |
|---|---|---|
| `parishes` | Parish identity/config | id, slug, name, pastorName, address, serviceTimes (jsonb), accentColor |
| `events` | Upcoming events | id, parishId, title, date, time, category |
| `testimonies` | Member testimonies | id, parishId, authorName, content, likes, isApproved |
| `connect_cards` | First-timer submissions | id, parishId, fullName, email, phone, interestInGroups (jsonb) |
| `meeting_requests` | Plain-form meeting request submissions | id, parishId, fullName, contact, preferredDateTime, reason, submittedAt |
| `service_subscribers` *(proposed)* | Email reminder opt-ins | id, parishId, email, serviceInterest |

Row Level Security enabled on all tables — only the Express server
(via service-role key) writes/reads directly; no table is browser-facing.

---

## 7. API Specification

**Current (as actually implemented at last check)**:

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/parishes` | Fetch parish config(s) |
| GET | `/api/events?parishId=…` | List events for a parish |
| GET | `/api/testimonies?parishId=…` | List approved testimonies |
| POST | `/api/testimonies` | Submit a new testimony (enters moderation) |
| POST | `/api/testimonies/:id/like` | Atomic like increment |
| POST | `/api/connect-cards` | Submit a Connect Card |
| POST | `/api/counsel` | **Outdated** — combined chat + meeting-request save via Ollama. To be deleted entirely, not refactored, since there's no chatbot at all anymore. |

**Target (once the PastorBot removal is done)**:

| Method | Route | Purpose |
|---|---|---|
| POST | `/api/meeting-requests` | Save a plain-form meeting request — no chat route exists or is needed |

No `/api/chat` route in the target state — there is no chatbot to serve.
`/api/counsel` is removed outright, not split into two routes; the
earlier plan to split it into `/api/chat` + `/api/meeting-requests` is
void now that PastorBot itself is gone (see Section 10).

**Admin routes (Phase 8, built after the church page, not yet
specified)**: listing/approving meeting requests and testimonies,
adding/editing/deleting events — all behind Supabase Auth.

---

## 8. Backend Implementation

- **Runtime**: Node + Express (`server.ts`)
- **Data layer**: Supabase client (`@supabase/supabase-js`), replacing
  the original in-memory arrays
- **Error handling**: all database calls wrapped, no unhandled failures
  should crash the server
- **Status**: migration written, **not yet executed** against the live
  Supabase project — this is the current blocking step

---

## 9. Frontend Implementation

- **Stack**: React + TypeScript + Vite + Tailwind
- **Key components**: `App.tsx` (main shell), `ConnectCard.tsx`,
  `GivingModal.tsx` (placeholder). `ParishConfigurator.tsx` (the
  "Novaxis" sidebar) and `PastorBot.tsx` are both being removed — the
  meeting request feature becomes a plain form component instead, not
  a chat component
- **Data source**: `parishData.ts` — real Mount Zion data, some fields
  still marked `TO BE FILLED`
- **Status**: functional locally; live-stream section still needs the
  honest link-out rebuild (Phase 6)

---

## 10. Assistant Integration — REMOVED

**Decision reversed**: PastorBot has been removed entirely. No AI
assistant, no Ollama Cloud integration, no chat interface. Per the
"simple, not complex" direction, this is replaced by a **plain form**
(name, contact, preferred time, reason) that saves directly to
`meeting_requests` — no conversation, no AI involved at all.

This also removes the need for the `/api/chat` vs. `/api/meeting-requests`
split discussed earlier — there's no chat to split out anymore. A single
`POST /api/meeting-requests` route (plain form submission) is now
sufficient. `OLLAMA_API_KEY` and the Ollama dependency can be removed
from `.env.example` and `package.json`.

---

## 11a. Reference-Site Feature Backlog (documented, not yet prioritized)

Identified from reviewing mtzn.com's structure. Captured here for
completeness — **none of these have a build order yet**, per explicit
decision to document first and prioritize later.

**Ministry pages (Adult / Youth / Kids)**
Three dedicated pages, replacing/supplementing the current flat
Departments list, each following the mission → schedule → warm invite
pattern noted earlier in this doc. Departments themselves: no
placeholder fields (no fake/TBD leader names or meeting times) — just
real descriptive text on what the ministry does and who it's for, plus
a dropdown/accordion explaining how to get involved.

**Expanded Connect Card**
Current fields: `fullName`, `email`, `phone`, `interestInGroups`.
Additional fields identified: first/last name split, address (2 lines),
city, state, zip, country, email-notification opt-in, spouse name,
children's names, number of prior visits, "wants to learn more" flag,
free-text notes.

**Prayer Request** — a separate, simpler form from the Connect Card:
name, email, request text only.

**"Next Step" meeting request**
Overlaps substantially with the existing `meeting_requests` flow (now
a plain form, not a chatbot) — additional fields identified: preferred contact method, service
attended, length of attendance, interests/passions, ministry interest.
**Recommendation**: extend the existing flow rather than build a
second, competing form — avoid duplicate data paths.

**Baptism signup** — separate form: name, phone, email, and a free-text
reason for wanting to be baptized.

**Daily devotion / spiritual rhythms** — static content page(s)
covering prayer, repentance, and generosity as ongoing practices. No
forms or database involvement.

**Events calendar view** — current implementation is list-only;
identified need for a month-based calendar view with a list/calendar
toggle and month navigation.

**Homepage hero slider** — current hero is a static image; identified
need for a rotating image slider.

**Counseling services — decision pending, do not build**
Distinct from the plain meeting request form in scope and sensitivity:
covers issues like anxiety, grief, trauma, and marital conflict, with a
detailed intake questionnaire, no-insurance/direct-payment scheduling,
and real licensed-counselor booking.

- **Open question, unresolved**: is this a real, currently-staffed
  service, or an aspirational feature copied from the reference site's
  structure without an underlying service yet in place?
- **Explicitly separate from the meeting request form** — that form
  only schedules a meeting with Pastor Hannah and does not provide
  counseling; this stays true regardless of how the counseling feature
  itself is eventually resolved
- Sensitive intake data (mental health history, relationship status,
  trauma) would need real privacy/confidentiality handling if this
  becomes real — not a casual bolt-on
- **No work should begin on this feature until the staffing question
  is resolved**

---

## 11. Deployment (planned, not yet executed)

- **Frontend**: Vercel or Netlify (free tier)
- **Backend**: needs a Node-capable free host (Express server, not
  static) — specific provider still TBD
- **Environment variables**: Supabase URL/keys (including Auth config
  for the future admin page), future Stripe/Resend keys — configured
  in the hosting platform, never committed to the repo. No Ollama key —
  that dependency is being removed entirely.
